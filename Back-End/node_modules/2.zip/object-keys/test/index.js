'use strict';

require('./isArguments');

require('./shim');
