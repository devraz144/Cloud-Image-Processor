export { __decorate as default } from 'tslib'
