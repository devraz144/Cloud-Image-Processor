export default function _AwaitValue(value) {
  this.wrapped = value;
}
