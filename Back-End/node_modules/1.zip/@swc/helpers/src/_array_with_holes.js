export default function _arrayWithHoles(arr) {
  if (Array.isArray(arr)) return arr;
}
